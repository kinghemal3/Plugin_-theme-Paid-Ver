<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '0d4d6c32b2026f4403a0');
