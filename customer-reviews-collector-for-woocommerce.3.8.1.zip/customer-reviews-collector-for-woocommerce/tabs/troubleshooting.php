<?php
defined('ABSPATH') or die('No script kiddies please!');
$auto_updates = get_option('auto_update_plugins', []);
$plugin_slug = "customer-reviews-collector-for-woocommerce/customer-reviews-collector-for-woocommerce.php";
if($ti_command == 'auto-update')
{
if(!in_array($plugin_slug, $auto_updates))
{
array_push($auto_updates, $plugin_slug);
update_option('auto_update_plugins', $auto_updates, false);
}
header('Location: admin.php?page='. $_page .'&tab=troubleshooting');
exit;
}
else if($ti_command == 're-create')
{
$update_checked = floatval(get_option($trustindex_collector->get_option_name('update-version-check'), 0));
$trustindex_collector->uninstall();
if($update_checked)
{
update_option($trustindex_collector->get_option_name('update-version-check'), $update_checked);
}
$trustindex_collector->activate();
header('Location: admin.php?page='. $_page);
exit;
}
$yes_icon = '<span class="dashicons dashicons-yes-alt"></span>';
$no_icon = '<span class="dashicons dashicons-dismiss"></span>';
$plugin_updated = ($trustindex_collector->get_plugin_current_version() <= "3.8.1");
?>
<div class="plugin-head"><?php echo TrustindexCollectorPlugin::___('Troubleshooting'); ?></div>
<div class="plugin-body">
<div class="card">
<div class="card-body">
<p class="size-16"><strong><?php echo TrustindexCollectorPlugin::___('If you have any problem, you should try these steps:'); ?></strong></p>
<ul class="troubleshooting-checklist">
<li>
<?php echo TrustindexCollectorPlugin::___("Trustindex plugin"); ?>
<ul>
<li>
<?php echo TrustindexCollectorPlugin::___('Use the latest version:') .' '. ($plugin_updated ? $yes_icon : $no_icon); ?>
<?php if(!$plugin_updated): ?>
<a href="/wp-admin/plugins.php"><?php echo TrustindexCollectorPlugin::___("Update"); ?></a>
<?php endif; ?>
</li>
<li>
<?php echo TrustindexCollectorPlugin::___('Use automatic plugin update:') .' '. (in_array($plugin_slug, $auto_updates) ? $yes_icon : $no_icon); ?>
<?php if(!in_array($plugin_slug, $auto_updates)): ?>
<a href="?page=<?php echo esc_url($_page); ?>&tab=troubleshooting&command=auto-update"><?php echo TrustindexCollectorPlugin::___("Enable"); ?></a>
<div class="alert alert-sm alert-warning"><?php echo TrustindexCollectorPlugin::___('You should enable it, to get new features and fixes automatically, right after they published!'); ?></div>
<?php endif; ?>
</li>
</ul>
</li>
<li>
<?php
$plugin_url = 'https://wordpress.org/support/plugin/' . $trustindex_collector->get_plugin_slug();
$screenshot_url = 'https://snipboard.io';
$screencast_url = 'https://streamable.com/upload-video';
$pastebin_url = 'https://pastebin.com';
echo TrustindexCollectorPlugin::___("If the problem/question still exists, please create an issue here: %s", [ '<a href="'. $plugin_url .'" target="_blank">'. $plugin_url .'</a>' ]);
?>
<br />
<?php echo TrustindexCollectorPlugin::___('Please help us with some information:'); ?>
<ul>
<li><?php echo TrustindexCollectorPlugin::___('Describe your problem'); ?></li>
<li><?php echo TrustindexCollectorPlugin::___('You can share a screenshot with %s', [ '<a href="'. $screenshot_url .'" target="_blank">'. $screenshot_url .'</a>' ]); ?></li>
<li><?php echo TrustindexCollectorPlugin::___('You can share a screencast video with %s', [ '<a href="'. $screencast_url .'" target="_blank">'. $screencast_url .'</a>' ]); ?></li>
<li><?php echo TrustindexCollectorPlugin::___('If you have an (webserver) error log, you can copy it to the issue, or link it with %s', [ '<a href="'. $pastebin_url .'" target="_blank">'. $pastebin_url .'</a>' ]); ?></li>
<li><?php echo TrustindexCollectorPlugin::___('And include the information below:'); ?></li>
</ul>
</li>
</ul>
<?php
$dir = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'customer-reviews-collector-for-woocommerce.php';
$plugin_data = get_plugin_data( $dir );
?>
<?php
$memory_limit = "N/A";
if(ini_get('memory_limit'))
{
$memory_limit = filter_var(ini_get('memory_limit'), FILTER_SANITIZE_STRING);
}
$upload_max = "N/A";
if (ini_get('upload_max_filesize'))
{
$upload_max = filter_var(ini_get('upload_max_filesize'), FILTER_SANITIZE_STRING);
}
$post_max = "N/A";
if (ini_get('post_max_size'))
{
$post_max = filter_var(ini_get('post_max_size'), FILTER_SANITIZE_STRING);
}
$max_execute = "N/A";
if (ini_get('max_execution_time'))
{
$max_execute = filter_var(ini_get('max_execution_time'));
}
?>
<textarea class="ti-troubleshooting-info" readonly><?php include $trustindex_collector->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'troubleshooting.php'; ?></textarea>
<div class="row">
<div class="col justify-content-end d-flex">
<a href=".ti-troubleshooting-info" class="btn btn-primary btn-copy2clipboard ti-pull-right ti-tooltip toggle-tooltip ti-tooltip-left">
<?php echo TrustindexCollectorPlugin::___("Copy to clipboard") ;?>
<span class="ti-tooltip-message">
<span style="color: #00ff00; margin-right: 2px">✓</span>
<?php echo TrustindexCollectorPlugin::___("Copied"); ?>
</span>
</a>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col plugin-subtitle"><?php echo TrustindexCollectorPlugin::___('Re-create plugin'); ?></div>
</div>
<div class="card">
<div class="card-body">
<p class="size-16"><?php echo TrustindexCollectorPlugin::___('Re-create the database tables of the plugin.<br />Please note: this removes all settings and invitations.'); ?></p>
<div class="row">
<div class="col justify-content-end d-flex">
<a href="?page=<?php echo $_page; ?>&tab=troubleshooting&command=re-create" class="btn btn-primary btn-loading-on-click"><?php echo TrustindexCollectorPlugin::___('Re-create plugin'); ?></a>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col plugin-subtitle"><?php echo TrustindexCollectorPlugin::___('Translation'); ?></div>
</div>
<div class="card">
<div class="card-body">
<p class="size-16">
<?php echo TrustindexCollectorPlugin::___('If you notice an incorrect translation in the plugin text, please report it here:'); ?>
 <a href="mailto:support@trustindex.io">support@trustindex.io</a>
</p>
</div>
</div>
</div>
