<?php
/*
Plugin Name: Customer Reviews Collector for WooCommerce
Plugin URI: https://wordpress.org/plugins/customer-reviews-collector-for-woocommerce/
Description: Collect reviews on Google, Facebook, Yelp, Trustindex and other platforms automatically, with the help of our system.
Tags: collect, Woocommerce reviews, customer reviews, Google reviews, review plugin
Version: 3.8.1
Author: Trustindex.io <support@trustindex.io>
Author URI: https://www.trustindex.io/
Contributors: trustindex
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: customer-reviews-collector-for-woocommerce
Domain Path: /languages
Donate link: https://www.trustindex.io/prices/
*/
/*
You should have received a copy of the GNU General Public License
along with Review widget addon for Divi. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
*/
/*
Copyright 2019 Trustindex Kft (email: support@trustindex.io)
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
require_once plugin_dir_path( __FILE__ ) . 'trustindex-collector-plugin.class.php';
$trustindex_collector = new TrustindexCollectorPlugin(__FILE__, "3.8.1");
register_activation_hook(__FILE__, [ $trustindex_collector, 'activate' ]);
register_deactivation_hook(__FILE__, [ $trustindex_collector, 'deactivate' ]);
add_action('plugins_loaded', [ $trustindex_collector, 'update' ]);
add_action('plugins_loaded', [ $trustindex_collector, 'loadI18N' ]);
add_action('woocommerce_order_status_changed', function($id) {
global $trustindex_collector;
global $wpdb;
$order = new WC_Order($id);
$trigger_event = str_replace('wc-', '', get_option($trustindex_collector->get_option_name('trigger-event'), $trustindex_collector->get_default_settings()['trigger-event']));
$frequency = intval(get_option($trustindex_collector->get_option_name('frequency'), $trustindex_collector->get_default_settings()['frequency']));
if($trustindex_collector->is_campaign_active() && $order->has_status($trigger_event))
{
$order_data = $order->get_data();
$email = strtolower($order_data['billing']['email']);
$customer_full_name = trim($order_data['billing']['first_name'] .' '. $order_data['billing']['last_name']);
if(!$customer_full_name)
{
$customer = new WC_Customer(get_post_meta($id, '_customer_user', true));
if($customer)
{
$customer_full_name = $customer->get_display_name();
}
}
if($email && !$trustindex_collector->is_email_unsubscribed($email))
{
$table_name = $trustindex_collector->get_tablename('schedule_list');
$saved_invites = 0;
if($frequency)
{
$wpdb->get_results("SELECT id FROM `$table_name` WHERE `email` LIKE '$email' AND TIMESTAMPDIFF(DAY, created_at, NOW()) <= ". 30 * $frequency);
$saved_invites = $wpdb->num_rows;
}
if(!$saved_invites)
{
$trigger_delay = intval(get_option($trustindex_collector->get_option_name('trigger-delay'), $trustindex_collector->get_default_settings()['trigger-delay']));
$timestamp = time() + ($trigger_delay * 86400);
if(!$trigger_delay)
{
$trustindex_collector->sendMail($email, [ 'customer_full_name' => $customer_full_name ], $trustindex_collector->register_schedule_sent($email, $id, null, $customer_full_name));
}
else
{
$date = date('Y-m-d H:i:s');
$wpdb->insert($table_name, [
'email' => $email,
'name' => $customer_full_name,
'order_id' => $id,
'timestamp' => $timestamp,
'created_at' => $date
]);
$wpdb->update($table_name, [ 'hash' => md5($wpdb->insert_id . '-' . $date) ], [ 'id' => $wpdb->insert_id ]);
}
}
}
}
});
add_action('init', function() {
global $trustindex_collector;
if(!isset($trustindex_collector) || is_null($trustindex_collector))
{
if(!class_exists('TrustindexCollectorPlugin'))
{
require_once plugin_dir_path( __FILE__ ) . 'trustindex-collector-plugin.class.php';
}
$trustindex_collector = new TrustindexCollectorPlugin(__FILE__, "3.8.1");
}
if(!wp_next_scheduled($trustindex_collector->get_schedule_cronname()))
{
wp_schedule_event(time(), 'hourly', $trustindex_collector->get_schedule_cronname());
}
});
add_action($trustindex_collector->get_schedule_cronname(), function() {
global $trustindex_collector;
global $wpdb;
$schedules = $trustindex_collector->get_pending_schedules();
foreach($schedules as $s)
{
$customer_full_name = "";
if($order = new WC_Order($s->order_id))
{
$order_data = $order->get_data();
$customer_full_name = trim($order_data['billing']['first_name'] .' '. $order_data['billing']['last_name']);
}
if(!$customer_full_name)
{
if($customer = new WC_Customer(get_post_meta($s->order_id, '_customer_user', true)))
{
$customer_full_name = $customer->get_display_name();
}
}
if(!$s->hash)
{
$s->hash = md5($s->id . '-' . $s->created_at);
$wpdb->update($trustindex_collector->get_tablename('schedule_list'), [ 'hash' => $s->hash ], [ 'id' => $s->id ]);
}
$trustindex_collector->sendMail($s->email, [ 'customer_full_name' => $customer_full_name ], $s->hash);
$trustindex_collector->register_schedule_sent($s->email, $s->order_id, $s->id);
}
});
add_action('init', array($trustindex_collector, 'unsubscribe'));
add_action('admin_menu', [ $trustindex_collector, 'add_setting_menu' ], 10);
add_filter('plugin_action_links', [ $trustindex_collector, 'add_plugin_action_links' ], 10, 2);
add_filter('plugin_row_meta', [ $trustindex_collector, 'add_plugin_meta_links' ], 10, 2);
add_action('init', [ $trustindex_collector, 'output_buffer' ]);
add_action('admin_enqueue_scripts', [ $trustindex_collector, 'add_scripts' ]);
add_filter('script_loader_tag', function($tag, $handle) {
if(strpos($tag, 'trustindex.io/loader.js') !== false && strpos($tag, 'defer async') === false) {
$tag = str_replace(' src', ' defer async src', $tag );
}
return $tag;
}, 10, 2);
add_action('wp_ajax_'. $trustindex_collector->get_email_template_action(), function() {
global $trustindex_collector;
if(!isset($_POST['email-text']) || !isset($_POST['email-footer-text']) || !isset($_POST['platform-url']))
{
global $wp_query;
$wp_query->set_404();
status_header(404);
exit;
}
echo $trustindex_collector->getEmailHtml(stripslashes($_POST['email-text']), stripslashes($_POST['email-footer-text']), $_POST);
exit;
});
add_action('parse_request', function() {
global $trustindex_collector;
global $wpdb;
$rating = intval(isset($_GET['rating']) ? $_GET['rating'] : 3);
$review_link = $trustindex_collector->get_random_platform_url();
$table_name = $trustindex_collector->get_tablename('schedule_list');
if(isset($_GET[ $trustindex_collector->get_response_key() ]))
{
$hash = sanitize_text_field($_GET[ $trustindex_collector->get_response_key() ]);
$res = $wpdb->get_results('SELECT * FROM `'. $table_name .'` WHERE hash LIKE "'. $hash .'" LIMIT 1', ARRAY_A);
$mode = sanitize_text_field(isset($_GET['mode']) ? $_GET['mode'] : 'clicked');
if(count($res) != 1)
{
global $wp_query;
$wp_query->set_404();
status_header(404);
exit;
}
$schedule = $res[0];
$key = $mode . '_at';
if(in_array($key, [ 'opened_at', 'clicked_at' ]) && empty($schedule[ $key ]))
{
$data = [];
$data[ $key ] = date('Y-m-d H:i:s');
if($key == 'clicked_at')
{
$data['opened_at'] = date('Y-m-d H:i:s');
}
$wpdb->update($table_name, $data, [ 'id' => $schedule['id'] ]);
}
if($mode == 'clicked')
{
if($rating <= 3)
{
header('Location: '. $trustindex_collector->get_feedback_url($hash, $rating));
}
else
{
header('Location: '. $review_link);
}
}
exit;
}
else if(isset($_GET[ $trustindex_collector->get_feedback_key() ]))
{
$hash = sanitize_text_field($_GET[ $trustindex_collector->get_feedback_key() ]);
if($hash)
{
$res = $wpdb->get_results('SELECT * FROM `'. $table_name .'` WHERE hash LIKE "'. $hash .'" LIMIT 1', ARRAY_A);
if(count($res) != 1)
{
global $wp_query;
$wp_query->set_404();
status_header(404);
exit;
}
$schedule = $res[0];
$is_test = false;
if(isset($_POST['text']))
{
$text = wp_kses_post(stripslashes($_POST['text']));
$wpdb->update($table_name, [
'feedback' => $text,
'feedback_at' => date('Y-m-d H:i:s')
], [ 'id' => $schedule['id'] ]);
$message = "
Hi,<br /><br />
Instead of a negative rating, this message was written by one of your customers.<br />
<strong>Please respond to your customer regarding the problem as soon as possible.</strong><br /><br />
Name: <strong>". $schedule['name'] ."</strong><br />
E-mail: <strong>". $schedule['email'] ."</strong><br />
Message: <strong>$text</strong><br />";
if($schedule['order_id'])
{
$order_url = admin_url('post.php?post='. $schedule['order_id'] .'&action=edit');
$message .= 'Order ID: <a href="'. $order_url .'" target="_blank">'. $schedule['order_id'] .'</a><br />';
}
$message .= "<br />
Thank you for your help.<br /><br />
Best regards,<br />
Trustindex Team";
$wc_mailer = WC()->mailer();
$wc_mailer->send(get_option('admin_email'), 'Trustindex: Respond to Your Customer', $trustindex_collector->getEmailHtml($message));
exit;
}
}
else
{
$schedule = [
'name' => 'John Smith',
'email' => 'example@gmail.com',
'feedback' => ''
];
$is_test = true;
}
$locale = isset($_GET['lang']) ? $_GET['lang'] : get_option($trustindex_collector->get_option_name('support-language'), $trustindex_collector->get_default_settings()['support-language']);
if($locale == 'en')
{
if(function_exists('switch_to_locale'))
{
switch_to_locale('en_US');
}
}
else
{
unload_textdomain(TrustindexCollectorPlugin::$text_domain, true);
$mo_file = $trustindex_collector->get_plugin_dir() . 'languages' . DIRECTORY_SEPARATOR . TrustindexCollectorPlugin::$text_domain . '-' . $locale . '.mo';
load_textdomain(TrustindexCollectorPlugin::$text_domain, $mo_file);
}
include $trustindex_collector->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'feedback.php';
exit;
}
});
add_action('admin_notices', function() {
if(class_exists('Woocommerce'))
{
return;
}
echo '<div class="notice notice-error is-dismissible"><p>'. TrustindexCollectorPlugin::___('WooCommerce is not activated, please activate it to use <strong>%s</strong>!', [ 'Customer Reviews Collector for WooCommerce' ]) .'</p></div>';
});
?>