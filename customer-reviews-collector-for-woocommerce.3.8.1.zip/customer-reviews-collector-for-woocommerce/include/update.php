<?php
require_once(ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'upgrade.php');
global $wpdb;
$update_checked = floatval(get_option($this->get_option_name('update-version-check'), 0));
$current_version = floatval($this->version);
if($update_checked < $current_version)
{

if($current_version >= 2)
{
$table_name = $this->get_tablename('schedule_list');
if(count($wpdb->get_results("SHOW COLUMNS FROM `$table_name` LIKE 'hash'")) == 0)
{
$wpdb->query("
ALTER TABLE `$table_name`
ADD `hash` VARCHAR(50) NOT NULL AFTER `created_at`,
ADD `opened_at` DATETIME NULL AFTER `hash`,
ADD `clicked_at` DATETIME NULL AFTER `opened_at`,
ADD `feedback` TEXT NOT NULL AFTER `clicked_at`,
ADD `feedback_at` DATETIME NULL AFTER `feedback`
");
}
$url = get_option($this->get_option_name('platform-url'), null);
if($url && !is_array($url))
{
$urls = [ [ 'url' => $url, 'percent' => 100 ] ];
update_option($this->get_option_name('platform-url'), $urls);
}
$text = get_option($this->get_option_name('email-text'), null);
if($text)
{
$text = str_replace('<p>{{button}}</p>', '<p><strong>Click the stars to review us</strong></p><p>{{stars}}</p>', $text);
update_option($this->get_option_name('email-text'), $text);
}
$is_active = get_option($this->get_option_name('campaign-active'), 1);
if($is_active)
{
update_option($this->get_option_name('campaign-active'), 1);
}
}

if($current_version >= 3.6)
{
$table_name = $this->get_tablename('schedule_list');
$res = $wpdb->get_results("SHOW FULL COLUMNS FROM `$table_name` WHERE Field IN ('name', 'feedback')");
if($res[0]->Collation != 'utf8mb4_unicode_520_ci')
{
$wpdb->query("ALTER TABLE `$table_name` CHANGE `name` `name` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL");
}
if($res[1]->Collation != 'utf8mb4_unicode_520_ci')
{
$wpdb->query("ALTER TABLE `$table_name` CHANGE `feedback` `feedback` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL");
}
}
update_option($this->get_option_name('update-version-check'), $current_version);
update_option($this->get_option_name('version'), $current_version);
}
?>