<?php
class TrustindexCollectorPlugin
{
private $plugin_file_path;
private $version;
public function __construct($plugin_file_path, $version)
{
$this->plugin_file_path = $plugin_file_path;
$this->version = $version;
}


public function get_plugin_dir()
{
return plugin_dir_path($this->plugin_file_path);
}
public function get_plugin_file_url($file, $add_versioning = true)
{
$url = plugins_url($file, $this->plugin_file_path);
if ($add_versioning)
{
$append_mark = strpos($url, "?") === FALSE ? "?" : "&";
$url .= $append_mark . 'ver=' . $this->version;
}
return $url;
}
public function get_plugin_slug()
{
return 'customer-reviews-collector-for-woocommerce';
}


public function activate()
{
include $this->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'activate.php';
update_option($this->get_option_name('update-version-check'), $this->version);
}
public function update()
{
include $this->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'update.php';
}
public function deactivate()
{
update_option($this->get_option_name('active'), '0');
}
public function uninstall()
{
include $this->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'uninstall.php';
if($timestamp = wp_next_scheduled($this->get_schedule_cronname()))
{
wp_unschedule_event($timestamp, $this->get_schedule_cronname());
}
$file = wp_upload_dir()['basedir'] . DIRECTORY_SEPARATOR . $this->get_email_logo_filename();
if(file_exists($file))
{
unlink($file);
}
}
public function output_buffer()
{
ob_start();
}
public function get_plugin_current_version()
{
add_action('http_api_curl', function($handle) {
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
}, 10);
$response = wp_remote_get('https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&request[slug]='. $this->get_plugin_slug());
$json = json_decode($response['body'], true);
if(!$json || !isset($json['version']))
{
return false;
}
return $json['version'];
}


public function get_tablename($name = "")
{
global $wpdb;
return $wpdb->prefix .'trustindex_collector_' . $name;
}
public function is_table_exists($name = "")
{
global $wpdb;
$table_name = $this->get_tablename($name);
return ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name);
}


public static $text_domain = 'trustindex-collector';
public function loadI18N()
{
load_plugin_textdomain(self::$text_domain, false, $this->get_plugin_slug() . DIRECTORY_SEPARATOR . 'languages');
}
public static function ___($text, $params = null)
{
if (!is_array($params))
{
$params = func_get_args();
$params = array_slice($params, 1);
}
return vsprintf(__($text, self::$text_domain), $params);
}
public static function getPluginTabs()
{
return [
self::___('Dashboard') => 'dashboard',
self::___('Requests') => 'requests',
self::___('Settings') => 'settings',
self::___('Display reviews') => 'display_reviews',
self::___('Unsubscribes') => 'unsubscribes',
self::___('Feature request') => 'feature_request',
self::___('Troubleshooting') => 'troubleshooting'
];
}


public function add_setting_menu()
{
$permission = 'edit_pages';
add_submenu_page(
'woocommerce',
'Trustindex.io',
self::___('Customer Reviews Collector') . ' <span class="awaiting-mod">'. self::___('New') .'</span>',
$permission,
$this->get_plugin_slug() . '/admin.php'
);
/*
$title = self::___('Customer Reviews Collector');
$menu_slug = 'trustindex-collector';//$this->get_plugin_slug() . '/admin.php';
add_menu_page(
$title,
$title,
$permission,
$menu_slug,
null,
$this->get_plugin_file_url('assets/img/trustindex-sign-logo.png')
);
foreach(self::getPluginTabs() as $name => $tab)
{
add_submenu_page(
$menu_slug,
$name,
$name,
$permission,
admin_url('admin.php?page='. $this->get_plugin_slug() .'/admin.php&tab='. $tab)
);
}
*/
}
public function add_plugin_action_links($links, $file)
{
$plugin_file = $this->get_plugin_slug() . '.php';
if(basename($file) == $plugin_file)
{
if(!class_exists('Woocommerce'))
{
return [ '<span style="color: red; font-weight: bold">'. self::___('Activate WooCommerce first!') .'</span>' ];
}
$new_item2 = '<a target="_blank" href="https://www.trustindex.io" target="_blank">by <span style="background-color: #4067af; color: white; font-weight: bold; padding: 1px 8px;">Trustindex.io</span></a>';
$new_item1 = '<a href="' . admin_url('admin.php?page=' . $this->get_plugin_slug() . '/admin.php') . '">' . self::___('Settings') . '</a>';
array_unshift($links, $new_item2, $new_item1);
}
return $links;
}
public function add_plugin_meta_links($meta, $file)
{
$plugin_file = $this->get_plugin_slug() . '.php';
if(basename($file) == $plugin_file)
{
$meta[] = '<a href="http://wordpress.org/support/view/plugin-reviews/'. $this->get_plugin_slug() .'" target="_blank" rel="noopener noreferrer">'. self::___('Rate our plugin') . '</a>';
}
return $meta;
}
public function add_scripts($hook)
{
$plugin_slug = $this->get_plugin_slug();
$tmp = explode('/', $hook);
$current_slug = array_shift($tmp);
if($plugin_slug == $current_slug)
{
if(file_exists($this->get_plugin_dir() . 'assets' . DIRECTORY_SEPARATOR . 'css' . DIRECTORY_SEPARATOR . 'admin.css'))
{
wp_enqueue_style('trustindex-collector-admin', $this->get_plugin_file_url('assets/css/admin.css'));
}
if(file_exists($this->get_plugin_dir() . 'assets' . DIRECTORY_SEPARATOR . 'js' . DIRECTORY_SEPARATOR . 'admin.js'))
{
wp_enqueue_script('trustindex-collector-admin', $this->get_plugin_file_url('assets/js/admin.js'));
}
if(file_exists($this->get_plugin_dir() . 'assets' . DIRECTORY_SEPARATOR . 'js' . DIRECTORY_SEPARATOR . 'bootstrap.bundle.min.js'))
{
wp_enqueue_script('trustindex-collector-boostrap', $this->get_plugin_file_url('assets/js/bootstrap.bundle.min.js'));
}
if(file_exists($this->get_plugin_dir() . 'assets' . DIRECTORY_SEPARATOR . 'js' . DIRECTORY_SEPARATOR . 'Chart.min.js'))
{
wp_enqueue_script('trustindex-collector-chart', $this->get_plugin_file_url('assets/js/Chart.min.js'));
}
}
}


public function get_option_name($opt_name)
{
if (!in_array($opt_name, $this->get_option_names()))
{
echo "Option not registered in plugin (TrustindexCollector class)";
}
return 'trustindex-collector-' . $opt_name;
}
public function get_option_names()
{
return [
'active',
'version',
'update-version-check',
'settings-state',
'campaign-active',
'platform-url',
'trigger-delay',
'trigger-event',
'frequency',
'email-sender',
'email-sender-email',
'email-subject',
'email-text',
'email-footer-text',
'rate-us-feedback',
'support-language'
];
}
public function get_default_settings()
{
$mailer = WC()->mailer();;
$domain = get_bloginfo('name');
return [
'platform-url' => [],
'trigger-delay' => 7,
'trigger-event' => 'wc-completed',
'frequency' => 0,
'email-sender' => $mailer->get_from_name(),
'email-sender-email' => $mailer->get_from_address(),
'email-subject' => 'Your opinion matters to '. $domain,
'email-text' => '<p>Dear {{customer_full_name}},</p><p>Thank you for choosing '. $domain .'.</p><p>Our customers\' opinion is important to us, as this way we can increase their satisfaction!</p><p>Please share your experiences with us!</p><p><strong>Click the stars to review us</strong></p><p>{{stars}}</p><p>It\'s only a minute for you, but a huge help for us.</p><p>Thank you in advance,<br />'. $domain .' team</p>',
'email-footer-text' => "You received this email because you made a purchase from $domain website.\nIf you don't want to receive this mail in the future, you can <a>unsubscribe here</a>.",
'support-language' => 'en'
];
}
public function save_option_from_request($name, $type = 'field')
{
$value = "";
if(isset($_REQUEST[ $name ]))
{
if($type == 'array')
{
$value = $_REQUEST[ $name ];
}
else if($type == 'text')
{
$value = trim(wp_kses_post(stripslashes($_REQUEST[ $name ])));
}
else
{
$value = trim(sanitize_text_field($_REQUEST[ $name ]));
}
}
update_option($this->get_option_name($name), $value, false);
}


public function get_response_key()
{
return 'trustindex-collector-response';
}
public function get_response_url($hash = null, $mode = 'clicked')
{
$url = site_url() . '?' . $this->get_response_key();
if($hash)
{
$url .= '=' . $hash;
}
if($mode)
{
$url .= '&mode=' . $mode;
}
return $url;
}
public function get_feedback_key()
{
return 'trustindex-collector-support-feedback';
}
public function get_feedback_url($hash = null, $rating = null)
{
$url = site_url() . '?' . $this->get_feedback_key();
if($hash)
{
$url .= '=' . $hash;
}
if($rating)
{
$url .= '&rating=' . $rating;
}
return $url;
}
public function get_email_template_action()
{
return 'trustindex_collector_email_template';
}
public function get_email_template_url()
{
return admin_url('admin-ajax.php') . '?action='. $this->get_email_template_action();
}
public function get_email_logo_filename()
{
return 'ti-collector-email-logo.png';
}
public function uploadLogoImage($image, $filename = null)
{
if(!$filename)
{
$filename = $this->get_email_logo_filename();
}
$wp_upload_dir = wp_upload_dir();
$decoded = base64_decode(str_replace(' ', '+', str_replace('data:image/png;base64,', '', $image)));
if(file_put_contents($wp_upload_dir['basedir'] . DIRECTORY_SEPARATOR . $filename, $decoded))
{
return $wp_upload_dir['baseurl'] . '/' . $filename;
}
return false;
}
public function getEmailHtml($ti_email_content = null, $ti_email_footer_content = null, $settings = [], $hash = null)
{
if(!isset($settings['customer_full_name']))
{
$settings['customer_full_name'] = '{{customer_full_name}}';
}
ob_start();
$link_bad = $this->get_feedback_url(null, '%star%');
$link_good = isset($settings['platform-url']) ? $settings['platform-url'][0]['url'] : "";
if($hash)
{
$link_bad = $this->get_response_url($hash) . '&rating=%star%';
$link_good = $link_bad;
$ti_email_content .= '<img src="'. $this->get_response_url($hash, 'opened') .'" alt="" />';
}
$stars_content = "";
for($i = 5; $i >= 1; $i--)
{
$stars_content .= '<tr><td style="padding: 4px 0px;"><a href="'. str_replace('%star%', $i, $i >= 4 ? $link_good : $link_bad) .'"><img width="220" src="https://cdn.trustindex.io/assets/img/email-'. $i .'-star-btn.png" alt=""></a></td></tr>';
}
$ti_email_content = str_replace([
'{{stars}}',
'{{customer_full_name}}'
], [
'<table cellpadding="0" cellspacing="0" style="table-layout: fixed"><tbody>'. $stars_content .'</tbody></table>',
$settings['customer_full_name']
], $ti_email_content);
$ti_email_footer_content = str_replace('<a>', '<a href="{{unsubscribe_url}}" target="_blank" style="font-size: inherit; font-family: inherit; color: inherit; text-decoration: underline">', nl2br($ti_email_footer_content));
if(isset($settings['logo-image']) && $settings['logo-image'])
{
$logo_image = $settings['logo-image'];
}
else
{
$wp_upload_dir = wp_upload_dir();
$file = $wp_upload_dir['basedir'] . DIRECTORY_SEPARATOR . $this->get_email_logo_filename();
if(file_exists($file))
{
$logo_image = $wp_upload_dir['baseurl'] . '/' . $this->get_email_logo_filename() . '?' . filemtime($file);
}
}
include $this->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'email.php';
return ob_get_clean();
}
public function sendMail($email, $settings = [], $hash = null)
{
foreach($this->get_default_settings() as $name => $default)
{
if(!isset($settings[ $name ]))
{
$settings[ $name ] = get_option($this->get_option_name($name), $default);
}
}
$old_sender_email = $this->get_default_settings()['email-sender-email'];
$old_sender_name = $this->get_default_settings()['email-sender'];
if($settings['email-sender-email'] && $settings['email-sender-email'] !== $old_sender_email)
{
update_option('woocommerce_email_from_address', $settings['email-sender-email'], false);
}
if($settings['email-sender'] && $settings['email-sender'] !== $old_sender_name)
{
update_option('woocommerce_email_from_name', $settings['email-sender'], false);
}
$wc_mailer = WC()->mailer();
$html = $this->getEmailHtml($settings['email-text'], $settings['email-footer-text'], $settings, $hash);
$html = str_replace('{{unsubscribe_url}}', get_site_url() .'?ti-collector-unsubscribe='. urlencode($email) .'&q='. md5($email), $html);
$wc_mailer->send($email, $settings['email-subject'], $html);
if($settings['email-sender-email'] && $settings['email-sender-email'] !== $old_sender_email)
{
update_option('woocommerce_email_from_address', $old_sender_email, false);
}
if($settings['email-sender'] && $settings['email-sender'] !== $old_sender_name)
{
update_option('woocommerce_email_from_name', $old_sender_name, false);
}
}


public function is_campaign_active()
{
return get_option($this->get_option_name('active'), 0) && get_option($this->get_option_name('campaign-active'), 0);
}
public function get_random_platform_url()
{
$url = "";
$urls = get_option($this->get_option_name('platform-url'), []);
if($urls)
{
if(!is_array($urls))
{
$urls = [[
'url' => $urls,
'percent' => 100
]];
}
$url = $urls[0];
usort($urls, function($a, $b) {
$ap = intval($a['percent']);
$bp = intval($b['percent']);
return $ap < $bp ? -1 : ($ap > $bp ? 1 : 0);
});
/*
[
[ ..., 'percent' => 20 ], --> between 1 and 20
[ ..., 'percent' => 30 ], --> between 21 and 50
[ ..., 'percent' => 50 ], --> between 51 and 100
]
*/
$percent_min = 1;
$random = random_int(1, 100);
foreach($urls as $u)
{
$percent_max = $percent_min + intval($u['percent']) - 1;
if($random >= $percent_min && $random <= $percent_max)
{
$url = $u['url'];
break;
}
$percent_min += intval($u['percent']);
}
}
return $url;
}
public function get_schedule_cronname()
{
return 'trustindex_collector_cron';
}
public function register_schedule_sent($email, $order_id, $schedule_id = null, $name = "")
{
global $wpdb;
$dbtable = $this->get_tablename('schedule_list');
$hash = null;
if($schedule_id)
{
$wpdb->query("UPDATE `$dbtable` SET sent = 1 WHERE id = '$schedule_id'");
}
else
{
$date = date('Y-m-d H:i:s');
$wpdb->insert($dbtable, [
'email' => $email,
'name' => $name,
'order_id' => $order_id,
'timestamp' => time(),
'sent' => 1,
'created_at' => $date
]);
$hash = md5($wpdb->insert_id . '-' . $date);
$wpdb->update($dbtable, [ 'hash' => $hash ], [ 'id' => $wpdb->insert_id ]);
}
return $hash;
}
public function get_pending_schedules()
{
require_once(ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'upgrade.php');
global $wpdb;
return $wpdb->get_results('SELECT id, email, order_id, hash, created_at FROM `'. $this->get_tablename('schedule_list') .'` WHERE `timestamp` <= '. time() .' AND sent = 0');
}
public function get_schedules($page = 1, $query = "")
{
require_once(ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'upgrade.php');
global $wpdb;
$limit = 10;
$sql = "SELECT * FROM `". $this->get_tablename('schedule_list') ."` WHERE email LIKE '%$query%' OR name like '%$query%' ORDER BY `timestamp`";
$total = $wpdb->get_results(str_replace('*', 'COUNT(id) as num', $sql))[0]->num;
$sql .= ' LIMIT ' . (($page - 1) * $limit) . ', ' . $limit;
return (object) [
'total' => $total,
'max_num_pages' => ceil($total / $limit),
'schedules' => $wpdb->get_results($sql)
];
}


public function is_email_unsubscribed($email)
{
global $wpdb;
$email = sanitize_email($email);
$res = $wpdb->get_results('SELECT id FROM `'. $this->get_tablename('unsubscribes') .'` WHERE email LIKE "'. $email .'" LIMIT 1');
return count($res) == 1;
}
public function unsubscribe()
{
global $wpdb;
if(isset($_GET['ti-collector-unsubscribe']))
{
$email = strtolower(sanitize_email($_GET['ti-collector-unsubscribe']));
$md5 = sanitize_text_field($_GET['q']);
if(!$email || $md5 !== md5($email))
{
header("HTTP/1.0 404 Not Found");
exit;
}
if($this->is_email_unsubscribed($email))
{
echo "Email already unsubscribed!";
exit;
}
$wpdb->insert($this->get_tablename('unsubscribes'), [
'email' => $email,
'created_at' => date('Y-m-d H:i:s')
]);
$wpdb->delete($this->get_tablename('schedule_list'), [ 'email' => $email, 'sent' => 0 ]);
echo "Email unsubscribed successfully!";
exit;
}
}
public function get_unsubscribes($page = 1, $query = "")
{
require_once(ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'upgrade.php');
global $wpdb;
$limit = 10;
$sql = "SELECT * FROM `". $this->get_tablename('unsubscribes') ."` WHERE email LIKE '%$query%' ORDER BY `created_at` DESC";
$total = $wpdb->get_results(str_replace('*', 'COUNT(id) as num', $sql))[0]->num;
$sql .= ' LIMIT ' . (($page - 1) * $limit) . ', ' . $limit;
return (object) [
'total' => $total,
'max_num_pages' => ceil($total / $limit),
'unsubscribes' => $wpdb->get_results($sql)
];
}
}
?>