<?php
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
if(!current_user_can('edit_pages'))
{
die('The account you\'re logged in to doesn\'t have permission to access this page.');
}
if(!class_exists('Woocommerce'))
{
die(TrustindexCollectorPlugin::___('Activate WooCommerce first!'));
}
$tabs = TrustindexCollectorPlugin::getPluginTabs();
$selected_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : null;
if(!in_array($selected_tab, array_values($tabs)))
{
$selected_tab = 'dashboard';
}
$_page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : null;
$_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : $selected_tab;
$ti_command = isset($_REQUEST['command']) ? sanitize_text_field($_REQUEST['command']) : null;
$settings_state = intval(get_option($trustindex_collector->get_option_name('settings-state'), 1));
?>
<div id="trustindex-collector-admin">
<div id="ti-assets-error" class="alert alert-warning alert-hidden"><?php echo TrustindexCollectorPlugin::___('For some reason, the <strong>CSS</strong> file required to run the plugin was not loaded.<br />One of your plugins is probably causing the problem.'); ?></div>
<script type="text/javascript">
window.onload = function() {
let not_loaded = [];
let loaded_count = 0;
let js_files = [
{
url: '<?php echo esc_url($trustindex_collector->get_plugin_file_url('assets/js/admin.js')); ?>',
id: 'common'
},
{
url: '<?php echo esc_url($trustindex_collector->get_plugin_file_url('assets/js/bootstrap.bundle.min.js')); ?>',
id: 'bootstrap'
},
{
url: '<?php echo esc_url($trustindex_collector->get_plugin_file_url('assets/js/Chart.min.js')); ?>',
id: 'chart'
}
];
let addElement = function(type, url, callback) {
let element = document.createElement(type);
if(type == 'script')
{
element.type = 'text/javascript';
element.src = url;
}
else
{
element.type = 'text/css';
element.rel = 'stylesheet';
element.href = url;
element.id = 'trustindex-collector-admin-css';
}
document.head.appendChild(element);
element.addEventListener('load', function() { callback(true); });
element.addEventListener('error', function() { callback(false); });
};
let isCSSExists = function() {
let link = document.getElementById('trustindex-collector-admin-css');
return link && Boolean(link.sheet);
};
let isJSExists = function(id) {
return typeof Trustindex_Collector_JS_loaded != 'undefined' && typeof Trustindex_Collector_JS_loaded[ id ] != 'undefined';
};
let process = function() {
if(loaded_count < js_files.length + 1)
{
return false;
}
if(not_loaded.length)
{
document.getElementById('trustindex-collector-admin').querySelector('.ti-wrapper').remove();
let warning_box = document.getElementById('ti-assets-error');
if(warning_box)
{
warning_box.style.display = 'block';
warning_box.querySelector('strong').innerHTML = not_loaded.join(', ');
}
}
};
if(!isCSSExists())
{
addElement('link', '<?php echo esc_url($trustindex_collector->get_plugin_file_url('assets/css/admin.css')); ?>', function(success) {
loaded_count++;
if(!success)
{
not_loaded.push('CSS');
}
process();
});
}
else
{
loaded_count++;
}
js_files.forEach(function(js) {
if(!isJSExists(js.id))
{
addElement('script', js.url, function(success) {
loaded_count++;
if(!success)
{
if(not_loaded.indexOf('JS') == -1)
{
not_loaded.push('JS');
}
}
process();
});
}
else
{
loaded_count++;
}
});
};
</script>
<div class="ti-wrapper">
<header class="plugin-header">
<div class="container">
<div class="row align-items-center">
<div class="plugin-title col-12 col-sm">
<h1><?php echo TrustindexCollectorPlugin::___('Customer Reviews Collector for WooCommerce'); ?></h1>
</div>
<div class="logo col-12 col-sm-auto ml-auto">
<img src="<?php echo esc_url($trustindex_collector->get_plugin_file_url('assets/img/trustindex.svg')); ?>" alt="">
</div>
</div>
</div>
</header>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<div class="container">
<ul class="navbar-nav col-12 col-sm-auto">
<?php foreach($tabs as $tab_name => $tab): ?>
<?php if($tab == 'feature_request'): ?>
</ul>
<ul class="navbar-nav col-12 col-sm-auto ml-auto">
<?php endif; ?>
<li class="nav-item">
<a
href="<?php echo esc_url(admin_url('admin.php?page='. $trustindex_collector->get_plugin_slug() .'/admin.php&tab='. $tab)); ?>"
class="nav-link <?php if($selected_tab == $tab): ?>active<?php endif; ?>"
 <?php if($selected_tab == $tab): ?>aria-current="page"<?php endif; ?>
>
<?php echo esc_html($tab_name); ?>
</a>
</li>
<?php endforeach; ?>
</ul>
</div>
</nav>
<div class="container-lg">
<main class="content">
<?php include($trustindex_collector->get_plugin_dir() . 'tabs' . DIRECTORY_SEPARATOR . $selected_tab . '.php'); ?>
</main>
</div>
</div>
</div>